export default {
  name: 'quest',
  title: 'Quest',
  type: 'document',
  fields: [
    { name: 'title', title: 'Title', type: 'string' },
    { name: 'description', title: 'Description', type: 'text' },
    { name: 'points', title: 'Points', type: 'number' },
    { name: 'isDaily', title: 'Is Daily Quest?', type: 'boolean' },
    { name: 'expiresAt', title: 'Expires At', type: 'datetime' },
  ],
}