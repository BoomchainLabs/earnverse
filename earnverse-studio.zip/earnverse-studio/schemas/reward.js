export default {
  name: 'reward',
  title: 'Reward',
  type: 'document',
  fields: [
    { name: 'name', title: 'Name', type: 'string' },
    { name: 'cost', title: 'Point Cost', type: 'number' },
    { name: 'image', title: 'Image', type: 'image' },
    { name: 'quantity', title: 'Quantity Available', type: 'number' },
    { name: 'description', title: 'Description', type: 'text' },
  ],
}