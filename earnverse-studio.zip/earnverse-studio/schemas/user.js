export default {
  name: 'user',
  title: 'User',
  type: 'document',
  fields: [
    { name: 'wallet', title: 'Wallet Address', type: 'string' },
    { name: 'points', title: 'Points', type: 'number' },
    { name: 'joinedAt', title: 'Joined At', type: 'datetime' },
  ],
}